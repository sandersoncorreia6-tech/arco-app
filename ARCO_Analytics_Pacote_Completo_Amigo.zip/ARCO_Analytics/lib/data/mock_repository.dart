import '../models/game.dart';
import '../models/insight.dart';
import '../models/lineup.dart';
import '../models/player.dart';
import '../models/shot.dart';

class MockRepository {
  static const players = <Player>[
    Player(id: 'p1', name: 'Lucas Silva', position: 'PG', number: 7, points: 18, assists: 8, rebounds: 4, steals: 2, blocks: 0, turnovers: 2, fgm: 7, fga: 13, threePm: 2, threePa: 5, ftm: 2, fta: 2, onCourtOffRating: 116.4, onCourtDefRating: 99.3, offCourtOffRating: 99.0, offCourtDefRating: 104.2),
    Player(id: 'p2', name: 'Rafael Costa', position: 'SG', number: 11, points: 12, assists: 4, rebounds: 6, steals: 3, blocks: 1, turnovers: 1, fgm: 5, fga: 9, threePm: 2, threePa: 4, ftm: 0, fta: 0, onCourtOffRating: 112.1, onCourtDefRating: 94.8, offCourtOffRating: 105.0, offCourtDefRating: 108.6),
    Player(id: 'p3', name: 'João Lima', position: 'SF', number: 23, points: 21, assists: 2, rebounds: 5, steals: 1, blocks: 0, turnovers: 4, fgm: 8, fga: 19, threePm: 3, threePa: 9, ftm: 2, fta: 3, onCourtOffRating: 106.2, onCourtDefRating: 108.0, offCourtOffRating: 110.4, offCourtDefRating: 101.9),
    Player(id: 'p4', name: 'Caio Martins', position: 'PF', number: 14, points: 10, assists: 2, rebounds: 9, steals: 1, blocks: 2, turnovers: 1, fgm: 4, fga: 7, threePm: 1, threePa: 2, ftm: 1, fta: 2, onCourtOffRating: 111.3, onCourtDefRating: 98.4, offCourtOffRating: 103.1, offCourtDefRating: 106.0),
    Player(id: 'p5', name: 'Bruno Alves', position: 'C', number: 33, points: 9, assists: 1, rebounds: 11, steals: 0, blocks: 2, turnovers: 2, fgm: 4, fga: 6, threePm: 0, threePa: 0, ftm: 1, fta: 3, onCourtOffRating: 108.6, onCourtDefRating: 95.9, offCourtOffRating: 107.4, offCourtDefRating: 109.1),
  ];

  static final games = <Game>[
    Game(opponent: 'Franca B', date: DateTime(2026, 10, 20), ourScore: 82, opponentScore: 75, possessions: 74, fgm: 30, fga: 63, threePm: 9, threePa: 27, ftm: 13, fta: 17, turnovers: 9, offensiveRebounds: 12, availableOffensiveRebounds: 37, opponentPoints: 75),
    Game(opponent: 'Marília', date: DateTime(2026, 10, 16), ourScore: 71, opponentScore: 76, possessions: 70, fgm: 26, fga: 65, threePm: 6, threePa: 28, ftm: 13, fta: 18, turnovers: 17, offensiveRebounds: 10, availableOffensiveRebounds: 39, opponentPoints: 76),
    Game(opponent: 'Bauru B', date: DateTime(2026, 10, 12), ourScore: 88, opponentScore: 79, possessions: 78, fgm: 33, fga: 67, threePm: 10, threePa: 25, ftm: 12, fta: 16, turnovers: 11, offensiveRebounds: 14, availableOffensiveRebounds: 35, opponentPoints: 79),
  ];

  static const lineups = <Lineup>[
    Lineup(name: 'Lineup A', players: ['Lucas', 'Rafael', 'João', 'Caio', 'Bruno'], possessions: 327, offensiveRating: 116.2, defensiveRating: 97.8),
    Lineup(name: 'Lineup B', players: ['Lucas', 'Rafael', 'João', 'Caio', 'Neto'], possessions: 141, offensiveRating: 109.4, defensiveRating: 102.6),
    Lineup(name: 'Lineup C', players: ['João', 'Pedro', 'Neto', 'Caio', 'Bruno'], possessions: 58, offensiveRating: 91.0, defensiveRating: 112.0),
  ];

  static const insights = <Insight>[
    Insight(title: 'Melhor quinteto identificado', description: 'A formação com Lucas, Rafael, João, Caio e Bruno tem o maior saldo por 100 posses.', level: InsightLevel.positive, evidence: '+18,4 Net Rating em 327 posses'),
    Insight(title: 'Turnovers em crescimento', description: 'A equipe perdeu mais bolas em dois dos últimos três jogos. O efeito aparece principalmente quando Lucas está fora.', level: InsightLevel.warning, evidence: 'TOV% sobe de 12,2% para 20,7% sem Lucas'),
    Insight(title: 'Valor oculto: Rafael', description: 'Rafael é apenas o 4º em pontos, mas possui o segundo maior impacto líquido da equipe.', level: InsightLevel.positive, evidence: '+20,9 pontos no On/Off'),
    Insight(title: 'Zona de baixa eficiência', description: 'O lado esquerdo do perímetro concentra volume alto com aproveitamento abaixo da média.', level: InsightLevel.warning, evidence: '27% de 3PT nessa zona'),
  ];

  static const shots = <Shot>[
    Shot(x: .25, y: .20, made: true, points: 2, player: 'Lucas Silva'),
    Shot(x: .42, y: .31, made: true, points: 2, player: 'Rafael Costa'),
    Shot(x: .68, y: .28, made: false, points: 2, player: 'João Lima'),
    Shot(x: .15, y: .55, made: false, points: 3, player: 'João Lima'),
    Shot(x: .82, y: .58, made: true, points: 3, player: 'Lucas Silva'),
    Shot(x: .50, y: .70, made: false, points: 3, player: 'Rafael Costa'),
    Shot(x: .72, y: .46, made: true, points: 3, player: 'Rafael Costa'),
  ];
}
